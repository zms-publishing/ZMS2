ZMSMediaPlayer
Display multimedia objects in ZMS with imagegalleries/rotators and mp3/mediaplayers

AUTHOR: Christian Meier, post@christianmeier.info

***********************************************************************

TERMS OF USE: 
- see LICENSE.txt

SETUP INSTRUCTIONS
- see INSTALL.txt

VERSION HISTORY
- see HISTORY.txt

REFERENCES:
- ZMS by www.zms-publishing.com
- ZOPE by zope.org
- PYTHON by python.org
- FLASH PLAYERS by jeroenwijering.com
- UFO by bobbyvandersluis.com/ufo
- ICONS by famfamfam.com

***********************************************************************